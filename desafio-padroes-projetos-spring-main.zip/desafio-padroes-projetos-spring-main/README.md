# desafio-padroes-projetos-spring

Trabalhando com padrões de projetos Singleton, Strategy e Facade em Spring Boot e Java.
Crindo uma api simples que cadastra cliente e seu endereço utilizando api externa ViaCep.
